import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService, User } from '../user.service';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  users: User[] = [];
  user: User = { name: '', email: '' };
  isEdit = false;

  constructor(private userService: UserService) {}

  ngOnInit() {
  this.users = []; // start empty
}

  // ADD
  addUser() {
    this.userService.createUser(this.user).subscribe(newUser => {
      newUser.id = this.users.length + 1; // fake id
      this.users.push(newUser); // update UI
      this.resetForm();
    });
  }

  // SELECT FOR EDIT
  selectUser(u: User) {
    this.user = { ...u };
    this.isEdit = true;
  }

  // UPDATE
  updateUser() {
    if (this.user.id) {
      this.userService.updateUser(this.user.id, this.user).subscribe(() => {
        const index = this.users.findIndex(u => u.id === this.user.id);
        this.users[index] = { ...this.user }; // update locally
        this.resetForm();
      });
    }
  }

  // DELETE
  deleteUser(id: number) {
    this.userService.deleteUser(id).subscribe(() => {
      this.users = this.users.filter(u => u.id !== id); // remove locally
    });
  }

  // RESET
  resetForm() {
    this.user = { name: '', email: '' };
    this.isEdit = false;
  }
}