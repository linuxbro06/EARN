import Swr from './Swr';

function App() {
  return (
    <div>
      <h1>Country flag</h1>
      <Swr />
    </div>
  );
  
}

export default App;