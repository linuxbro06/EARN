import useSWR from "swr";

const fetcher = (url) =>
  fetch(url).then((res) => res.json());

const Swr = () => {
  const { data, error, isLoading } = useSWR(
    "https://restcountries.com/v3.1/alpha/IN?fields=name,flags",
    fetcher
  );

  if (error) return <div className="failed">Failed to load</div>;
  if (isLoading) return <div className="loading">Loading...</div>;

  // API returns an object, not an array
  return (
    <div>
      <img
        src={data.flags.png}  // India flag
        alt={data.name.common}
        width={150}
      />
      <p>{data.name.common}</p>
    </div>
  );
};

export default Swr;