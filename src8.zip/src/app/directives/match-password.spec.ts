import { MatchPassword } from './match-password';

describe('MatchPassword', () => {
  it('should create an instance', () => {
    const directive = new MatchPassword();
    expect(directive).toBeTruthy();
  });
});
