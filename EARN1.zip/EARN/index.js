const http = require("http");
const express = require("express");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Handle socket connections
io.on('connection', (socket) => {
    console.log("A user connected");

    // Listen for user messages and broadcast them
    socket.on("user-message", (message) => {
        console.log("Received message:", message);
        io.emit("message", message); // Broadcast message to all connected clients
    });

    // Handle disconnection
    socket.on('disconnect', () => {
        console.log("A user disconnected");
    });
});

// Serve static files from the 'public' directory
app.use(express.static(path.resolve("./public")));

// Serve the index.html file when the root URL is requested
app.get('/', (req, res) => {
    res.sendFile(path.resolve("public/index.html"));
});

// Start the server on port 9000
server.listen(9000, () => {
    console.log(`Server started on port 9000`);
});
