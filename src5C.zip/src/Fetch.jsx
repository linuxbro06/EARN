import { useState, useEffect } from 'react';

const Fetch = () => {
  const [photos, setPhotos] = useState([]);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/photos')
      .then((res) => { return res.json(); })
      .then((data) => {console.log(data);
        setPhotos(data.slice(0, 20)); // limit data
      });
  }, []);

  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "10px" }}>
      {photos.map((photo) => (
        <img
          key={photo.id}
          src={photo.url}
          alt={photo.title}
          width={100}
        />
      ))}
    </div>
  );
};

export default Fetch;