import Fetch from "./Fetch";

function App() {
  return (
    <div>
      <h1></h1>
      <Fetch />
    </div>
  );
  
}

export default App;